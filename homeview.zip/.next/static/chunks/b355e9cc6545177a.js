__turbopack_load_page_chunks__("/_app", [
  "static/chunks/e60ef129113f6e24.js",
  "static/chunks/e97507ae391cc78b.js",
  "static/chunks/turbopack-57c0902ae4001036.js"
])
