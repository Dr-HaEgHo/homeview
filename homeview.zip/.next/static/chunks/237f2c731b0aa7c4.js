__turbopack_load_page_chunks__("/_error", [
  "static/chunks/17722e3ac4e00587.js",
  "static/chunks/e97507ae391cc78b.js",
  "static/chunks/turbopack-eee7d88f19556a33.js"
])
