globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": [
      "static/chunks/e60ef129113f6e24.js",
      "static/chunks/e97507ae391cc78b.js",
      "static/chunks/turbopack-57c0902ae4001036.js"
    ],
    "/_error": [
      "static/chunks/17722e3ac4e00587.js",
      "static/chunks/e97507ae391cc78b.js",
      "static/chunks/turbopack-eee7d88f19556a33.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [
    "static/chunks/a6dad97d9634a72d.js"
  ],
  "lowPriorityFiles": [],
  "rootMainFiles": [
    "static/chunks/f2441e65e5af3638.js",
    "static/chunks/522518d740397639.js",
    "static/chunks/2008ffcf9e5b170c.js",
    "static/chunks/c19da6693934fea1.js",
    "static/chunks/8082ab48faca5ea1.js",
    "static/chunks/turbopack-597c1da8196c491d.js"
  ],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];