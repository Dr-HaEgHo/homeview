var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/props/[id]/route.js")
R.c("server/chunks/[root-of-the-server]__c88f7f76._.js")
R.c("server/chunks/[root-of-the-server]__3c29c445._.js")
R.m(72536)
R.m(44600)
module.exports=R.m(44600).exports
