var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/types/route.js")
R.c("server/chunks/[root-of-the-server]__42cf8457._.js")
R.c("server/chunks/[root-of-the-server]__3c29c445._.js")
R.c("server/chunks/_05d0ec0d._.js")
R.m(59898)
R.m(70622)
module.exports=R.m(70622).exports
